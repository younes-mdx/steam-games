BETTER BEAST CREST - 2.3.0
A progression-focused rework of the Beast Crest that adds tool slots, extends rage duration, and improves healing so it scales with other crests.

:: REQUIREMENTS ::
• Silksong (obviously)
• BepInEx 5.4.23.3

:: FEATURES ::
• Rank 1 – Binding restores 1 mask instantly, and up to 2 masks can still be regained by attacking enemies
• Rank 2 – Adds a blue tool slot and Extends rage duration by 20%
• Rank 3 – Adds a yellow tool slot and increases maximum healing to 4 masks (1 immediate, 3 via lifesteal)
• Progression tied to unlocking new ranks of the Hunter Crest — works on new and existing saves
• All features are configurable in the mod’s config file

:: EXTRA STUFF ::
• You can swap the down air attack in the config
• You can swap the center tool slots (normally red/skill/red) to another color in the config
• You can change the rage damage multiplier at each rank in the config
• You can change the rage attack speed multiplier at each rank in the config

:: GENERAL OTHER STUFF ::
• Not a cheat mod — progression stays balanced while making Beast Crest a viable choice
• Almost every aspect is configurable: tool slot unlocks, healing, rage bonuses, and immediate bind heal
• Safe to install mid-playthrough
• Safe to uninstall (see notes below)

:: INSTALLATION ::

Install BepInEx 5.4.23.3, launch the game once, then close it. Confirm winhttp.dll exists in the game root folder and BepInEx.dll exists in:
[Game Install Directory]/BepInEx/core/

Place BetterBeastCrest.dll in:
[Game Install Directory]/BepInEx/plugins/

:: CONFIGURATION ::
Launch the game once to create the config file, make changes in
[Game Install Directory]/BepInEx/config/BetterBeastCrest.cfg

:: UNINSTALLATION ::
• Delete BetterBeastCrest.dll from the plugins folder
• If you already unlocked your blue slot, the memory locket will not be refunded
• Unequip any tools from the blue slot before removal to avoid confusion
• Save files will not be damaged even if the mod is removed mid-playthrough

:: KNOWN ISSUES ::
• No Localization at this time. If you speak another language and would like to provide me with some localized text to use feel free to post it and I'll add it when I have time.
  The description is dynamic based on your config settings though so it's not quite as simple as providing a single translated line of text.

:: CREDITS ::
♦ Team Cherry for Silksong
♦ BepInEx team for the framework
♦ Harmony for runtime patching